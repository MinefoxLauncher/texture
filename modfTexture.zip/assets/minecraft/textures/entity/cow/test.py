
import base64 


Skin = {"textures":{"SKIN":{"url":"https://raw.githubusercontent.com/MinefoxLauncher/images/main/cow_red_mooshroom.png"}}}



# img = open('cogoVacahead.png', 'rb').read()
# img = "{".encode()+img+"}".encode()
# enc = base64.b64encode(img)

# print(enc.decode())